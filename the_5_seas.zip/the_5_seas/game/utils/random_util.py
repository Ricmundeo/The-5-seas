import random

def random_chance(percent):
    return random.randint(1, 100) <= percent
