def log(msg):
    print(f"[LOG]: {msg}")
