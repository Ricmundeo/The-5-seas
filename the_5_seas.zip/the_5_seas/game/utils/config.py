class Config:
    SCREEN_WIDTH = 800
    SCREEN_HEIGHT = 600
    FULLSCREEN = True
