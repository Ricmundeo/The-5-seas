def save_file(path, data):
    with open(path, 'w') as f:
        f.write(data)

def load_file(path):
    with open(path, 'r') as f:
        return f.read()
