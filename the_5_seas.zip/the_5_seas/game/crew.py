class CrewMember:
    def __init__(self, name, role):
        self.name = name
        self.role = role
        print(f"Crew member {self.name} assigned as {self.role}")
