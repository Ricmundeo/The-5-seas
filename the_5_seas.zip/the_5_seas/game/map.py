class Map:
    def __init__(self):
        self.zones = []
        print("Map created")

    def add_zone(self, zone):
        self.zones.append(zone)
        print(f"Zone {zone.name} added to map")
