class Ship:
    def __init__(self, name, health=100):
        self.name = name
        self.health = health
        print(f"Ship {self.name} with {self.health} HP created")
