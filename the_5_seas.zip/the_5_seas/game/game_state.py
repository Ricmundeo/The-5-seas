import random
from game.combat_engine import CombatEngine
from game.enemies import Enemy

# inside GameState class...
def run(self):
    print("Starting game loop...")
    while self.running:
        user_input = input("Move (north/south/east/west or quit): ").lower()
        if user_input == "quit":
            self.running = False
            print("Game over.")
        elif user_input in ["north", "south", "east", "west"]:
            self.controller.move(user_input)
            zone = self.map_manager.get_zone(self.controller.position)
            print(f"You are now in: {zone.name} (Danger: {zone.danger_level})")

            # Chance of encounter
            if random.random() < (zone.danger_level * 0.1):
                print("⚠️ An enemy approaches!")
                enemy = Enemy("Pirate Raider", 40)
                combat = CombatEngine(self.player, enemy)
                result = combat.combat_turn()
                if result == "lose":
                    self.running = False
                    print("💀 You died at sea.")
        else:
            print("Invalid input.")
