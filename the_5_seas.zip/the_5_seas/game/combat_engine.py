import random

class CombatEngine:
    def __init__(self, player, enemy):
        self.player = player
        self.enemy = enemy
        self.in_combat = True
        print(f"Combat started with {enemy.name} (HP: {enemy.health})")

    def player_attack(self):
        dmg = random.randint(5, 15)
        self.enemy.health -= dmg
        print(f"You hit {self.enemy.name} for {dmg} damage!")

    def enemy_attack(self):
        dmg = random.randint(3, 12)
        self.player.health -= dmg
        print(f"{self.enemy.name} hits you for {dmg} damage!")

    def combat_turn(self):
        while self.in_combat:
            action = input("Choose action (attack/run): ").lower()
            if action == "attack":
                self.player_attack()
                if self.enemy.health <= 0:
                    print(f"You defeated {self.enemy.name}!")
                    self.in_combat = False
                    return "win"

                self.enemy_attack()
                if self.player.health <= 0:
                    print("You were defeated...")
                    self.in_combat = False
                    return "lose"
            elif action == "run":
                if random.random() > 0.5:
                    print("You escaped!")
                    self.in_combat = False
                    return "escaped"
                else:
                    print("Failed to escape!")
                    self.enemy_attack()
                    if self.player.health <= 0:
                        print("You were defeated while trying to escape...")
                        self.in_combat = False
                        return "lose"
            else:
                print("Invalid action.")
