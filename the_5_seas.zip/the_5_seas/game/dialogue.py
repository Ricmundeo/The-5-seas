class Dialogue:
    def __init__(self, speaker, message):
        self.speaker = speaker
        self.message = message

    def display(self):
        print(f"{self.speaker}: {self.message}")
