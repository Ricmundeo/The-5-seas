class Player:
    def __init__(self, name):
        self.name = name
        self.health = 100
        self.inventory = []
        print(f"Player '{self.name}' created with 100 HP")
