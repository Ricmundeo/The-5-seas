class EventManager:
    def __init__(self):
        self.events = []
        print("EventManager initialized")

    def trigger_event(self, event_name):
        print(f"Event triggered: {event_name}")
        self.events.append(event_name)
