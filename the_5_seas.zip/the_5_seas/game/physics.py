class PhysicsEngine:
    def __init__(self):
        print("Physics engine online")

    def apply_force(self, entity, force):
        print(f"Applying {force} force to {entity}")
