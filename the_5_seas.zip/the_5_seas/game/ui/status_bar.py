class StatusBar:
    def __init__(self):
        print("Status bar ready")

    def update(self, health, gold):
        print(f"Status - Health: {health}, Gold: {gold}")
