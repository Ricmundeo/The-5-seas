class MapUI:
    def __init__(self):
        print("Map UI initialized")

    def render(self):
        print("Map UI rendered with sea zones")
