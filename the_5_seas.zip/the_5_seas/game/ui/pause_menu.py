class PauseMenu:
    def __init__(self):
        print("Pause menu initialized")

    def toggle(self):
        print("Game paused/unpaused")
