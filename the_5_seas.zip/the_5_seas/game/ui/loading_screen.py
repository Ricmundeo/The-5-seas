class LoadingScreen:
    def __init__(self):
        print("Loading screen active...")

    def finish(self):
        print("Loading complete!")
