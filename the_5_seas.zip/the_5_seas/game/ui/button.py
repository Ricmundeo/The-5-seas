class Button:
    def __init__(self, label):
        self.label = label
        print(f"Button '{self.label}' created")

    def click(self):
        print(f"Button '{self.label}' clicked")
