class CreditsScreen:
    def __init__(self):
        print("Credits screen opened")

    def show(self):
        print("Thanks for playing The 5 Seas!")
