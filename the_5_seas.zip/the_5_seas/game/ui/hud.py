class HUD:
    def __init__(self):
        print("HUD loaded")

    def update(self):
        print("HUD updated with player stats")
