class Menu:
    def __init__(self, title):
        self.title = title
        print(f"Menu '{self.title}' opened")

    def display(self):
        print(f"Showing menu: {self.title}")
