class DialogBox:
    def __init__(self, speaker, text):
        self.speaker = speaker
        self.text = text

    def show(self):
        print(f"[{self.speaker}]: {self.text}")
