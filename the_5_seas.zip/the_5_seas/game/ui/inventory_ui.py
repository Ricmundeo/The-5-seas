class InventoryUI:
    def __init__(self):
        print("Inventory UI initialized")

    def refresh(self):
        print("Inventory UI refreshed")
