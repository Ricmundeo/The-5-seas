# Auto-generated file: the_5_seas/game/networking/packet.py

