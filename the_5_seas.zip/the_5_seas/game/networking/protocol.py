# Auto-generated file: the_5_seas/game/networking/protocol.py

