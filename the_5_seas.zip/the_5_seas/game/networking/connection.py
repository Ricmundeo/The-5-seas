# Auto-generated file: the_5_seas/game/networking/connection.py

