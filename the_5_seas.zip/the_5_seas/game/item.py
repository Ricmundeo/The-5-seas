class Item:
    def __init__(self, name, effect):
        self.name = name
        self.effect = effect
        print(f"Item '{self.name}' created with effect: {self.effect}")
