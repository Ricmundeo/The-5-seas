from game.sea_zone import SeaZone

class MapManager:
    def __init__(self):
        self.zones = {
            (0, 0): SeaZone("Calm Bay", 1),
            (1, 0): SeaZone("Shark Strait", 4),
            (0, 1): SeaZone("Silent Depths", 2),
            (-1, 0): SeaZone("Sirens’ Cove", 5),
            (0, -1): SeaZone("Merchant Route", 1)
        }
        print("MapManager initialized with zones")

    def get_zone(self, position):
        coords = (position.x, position.y)
        return self.zones.get(coords, SeaZone("Open Ocean", 0))
