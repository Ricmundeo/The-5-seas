from game.utils.vector import Vector2

class PlayerController:
    def __init__(self, player):
        self.player = player
        self.position = Vector2(0, 0)
        print(f"PlayerController initialized at {self.position}")

    def move(self, direction):
        if direction == "north":
            self.position.y += 1
        elif direction == "south":
            self.position.y -= 1
        elif direction == "east":
            self.position.x += 1
        elif direction == "west":
            self.position.x -= 1
        print(f"Player moved {direction} to {self.position}")
