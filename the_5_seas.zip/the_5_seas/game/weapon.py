class Weapon:
    def __init__(self, name, damage):
        self.name = name
        self.damage = damage
        print(f"Weapon {self.name} with damage {self.damage} created")
