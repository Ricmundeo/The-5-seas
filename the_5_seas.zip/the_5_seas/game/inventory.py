class Inventory:
    def __init__(self):
        self.items = []
        print("Inventory initialized")

    def add_item(self, item):
        self.items.append(item)
        print(f"Added item: {item.name}")

    def list_items(self):
        for item in self.items:
            print(f"- {item.name}: {item.effect}")
