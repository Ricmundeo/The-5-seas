class UIManager:
    def __init__(self):
        print("UI Manager initialized")

    def draw(self):
        print("Drawing UI elements...")
