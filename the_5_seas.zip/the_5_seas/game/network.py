class NetworkManager:
    def __init__(self):
        self.connected = False
        print("NetworkManager initialized")

    def connect(self, server_address):
        self.connected = True
        print(f"Connected to server at {server_address}")
