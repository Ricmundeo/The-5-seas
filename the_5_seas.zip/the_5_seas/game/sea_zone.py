class SeaZone:
    def __init__(self, name, danger_level=0):
        self.name = name
        self.danger_level = danger_level
        print(f"SeaZone {self.name} with danger level {self.danger_level} created")
