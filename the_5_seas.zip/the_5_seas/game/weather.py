class WeatherSystem:
    def __init__(self):
        self.current_weather = "Clear"
        print("Weather system initialized")

    def change_weather(self, new_weather):
        self.current_weather = new_weather
        print(f"Weather changed to: {self.current_weather}")
