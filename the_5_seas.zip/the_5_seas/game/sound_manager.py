class SoundManager:
    def __init__(self):
        print("Sound system initialized")

    def play_sound(self, sound_name):
        print(f"Playing sound: {sound_name}")
