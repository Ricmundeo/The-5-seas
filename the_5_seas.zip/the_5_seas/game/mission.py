class Mission:
    def __init__(self, title, description, reward):
        self.title = title
        self.description = description
        self.reward = reward
        print(f"Mission '{self.title}' initialized")

    def complete(self):
        print(f"Mission '{self.title}' completed. Reward: {self.reward}")
