# Auto-generated file: the_5_seas/game/animation.py

