class NPC:
    def __init__(self, name, role):
        self.name = name
        self.role = role
        print(f"NPC '{self.name}' as {self.role} created")
