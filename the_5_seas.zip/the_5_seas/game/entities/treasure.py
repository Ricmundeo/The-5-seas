class Treasure:
    def __init__(self, contents, value):
        self.contents = contents
        self.value = value
        print(f"Treasure found: {self.contents} worth {self.value} gold")
