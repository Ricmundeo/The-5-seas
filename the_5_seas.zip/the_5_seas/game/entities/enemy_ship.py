class EnemyShip:
    def __init__(self, name, level):
        self.name = name
        self.level = level
        print(f"Enemy ship '{self.name}' (Level {self.level}) created")
