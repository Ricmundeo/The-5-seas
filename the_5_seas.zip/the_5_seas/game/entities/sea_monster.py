class SeaMonster:
    def __init__(self, species, strength):
        self.species = species
        self.strength = strength
        print(f"Sea Monster '{self.species}' with strength {self.strength} awakened!")
