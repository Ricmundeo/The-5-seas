class FishingSpot:
    def __init__(self, location, rarity):
        self.location = location
        self.rarity = rarity
        print(f"Fishing spot discovered at {self.location}, rarity: {self.rarity}")
