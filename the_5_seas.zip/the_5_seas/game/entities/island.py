class Island:
    def __init__(self, name, size):
        self.name = name
        self.size = size
        print(f"Island '{self.name}' (size {self.size}) discovered")
