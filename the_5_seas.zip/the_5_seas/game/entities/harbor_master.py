class HarborMaster:
    def __init__(self, name):
        self.name = name
        print(f"Harbor Master '{self.name}' at your service")

    def greet(self):
        print(f"{self.name}: Welcome to our port, captain.")
