class Port:
    def __init__(self, name, population):
        self.name = name
        self.population = population
        print(f"Port '{self.name}' with population {self.population} loaded")
