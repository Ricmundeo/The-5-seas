class MapMarker:
    def __init__(self, label, position):
        self.label = label
        self.position = position
        print(f"Map marker '{self.label}' placed at {self.position}")
