class Enemy:
    def __init__(self, name, health):
        self.name = name
        self.health = health
        print(f"Enemy '{self.name}' with {self.health} HP created")
