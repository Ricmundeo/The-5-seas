class InputHandler:
    def __init__(self):
        print("Input Handler initialized")

    def get_input(self):
        print("Getting player input...")
        return None
