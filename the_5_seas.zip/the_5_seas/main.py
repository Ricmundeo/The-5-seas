# Auto-generated file: the_5_seas/main.py

from game.game_state import GameState

def main():
    print("Welcome to The 5 Seas!")
    game = GameState()
    game.run()

if __name__ == "__main__":
    main()
